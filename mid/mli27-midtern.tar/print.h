#ifndef PRINT_H_
#define PRINT_H_

// list print function and printMulticol function

void display_one(FTSENT* , Length);
void display_mul(char** pCache, Length);
#endif
